class MyAnimation {
  static const String noInternet = "assets/animation/no_internet.json";

  static const String emptyChat = "assets/animation/emptyChat.json";

  static const String rideDetailsLoadingAnimation = "assets/animation/map.json";

  static const String searching = "assets/animation/searching.json";

  static const String notFound = "assets/animation/not_found.json";

  static const String maintenance = "assets/animation/maintance.json";
}
