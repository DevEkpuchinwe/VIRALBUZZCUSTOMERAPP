class RouteInfo {
  double distanceInMeters;
  double timeInSeconds;

  RouteInfo(this.distanceInMeters, this.timeInSeconds);
}
