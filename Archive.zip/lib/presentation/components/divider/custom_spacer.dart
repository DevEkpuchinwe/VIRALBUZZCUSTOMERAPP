import 'package:flutter/widgets.dart';

Widget spaceDown(double? height) {
  return SizedBox(
    height: height ?? 10,
  );
}

Widget spaceSide(double? width) {
  return SizedBox(
    width: width ?? 10,
  );
}
